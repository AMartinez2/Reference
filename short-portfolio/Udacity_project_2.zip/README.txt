The second project for the Udacity Full Stack Web Developer Nanodegree Program. 
This simple portfolio website contains links to github repos containing personal projects of mine. 

The main page is found within index.html and can be opened from any perferred webbrowser. 